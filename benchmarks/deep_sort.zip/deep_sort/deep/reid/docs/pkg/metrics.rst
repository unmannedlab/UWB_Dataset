.. _torchreid_metrics:

torchreid.metrics
=================


Distance
---------

.. automodule:: torchreid.metrics.distance
    :members:


Accuracy
--------

.. automodule:: torchreid.metrics.accuracy
    :members:


Rank
-----

.. automodule:: torchreid.metrics.rank
    :members: evaluate_rank